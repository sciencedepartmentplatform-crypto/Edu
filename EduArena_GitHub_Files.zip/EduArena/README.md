# EduArena

A responsive front-end starter website for a secondary-school quiz platform.

## Files
- `index.html` — page structure and sections
- `style.css` — layout, colours, responsive styling
- `script.js` — quiz selection, random question order, answer checking, feedback, scoring, and demo mode buttons

## Run locally
Open `index.html` in a browser. The CSS and JavaScript files must remain in the same folder as `index.html`.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new repository, for example `eduarena`.
2. Upload `index.html`, `style.css`, `script.js`, and this `README.md` to the repository's root folder.
3. Open the repository's **Settings → Pages**.
4. Under the build/deployment section, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for the published website URL to appear in the Pages section.

## Important current limitations
- This is a front-end demo. The question bank contains sample questions and is shuffled to create a different quiz order. It does **not** generate new original questions with AI.
- The current demo question bank uses sample questions for all six class levels. The same starter bank is shared across classes; replace/add questions appropriate to each curriculum and class.
- Login, online score history, live 1-vs-1 play, 4-vs-4 squad rooms, anti-cheating, and an admin question manager need a secure backend/database.
- Do not collect student passwords or sensitive information in this static version.
- Before using this with real students, have a trusted adult/developer review privacy, security, curriculum accuracy, and child-safety requirements.
