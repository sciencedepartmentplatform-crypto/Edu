const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const questionBank = [
  {department:"Science",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Biology",question:"Which part of a plant mainly absorbs water from the soil?",options:["Flower","Root hairs","Leaves","Stem"],answer:1,explanation:"Root hairs increase the surface area available for absorbing water and mineral salts."},
  {department:"Science",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Biology",question:"What is the basic structural and functional unit of life?",options:["Tissue","Organ","Cell","System"],answer:2,explanation:"The cell is the basic structural and functional unit of living organisms."},
  {department:"Science",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Chemistry",question:"What is the chemical formula for water?",options:["CO₂","H₂O","O₂","NaCl"],answer:1,explanation:"A water molecule contains two hydrogen atoms and one oxygen atom: H₂O."},
  {department:"Science",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Physics",question:"What is the SI unit of force?",options:["Joule","Watt","Newton","Metre"],answer:2,explanation:"Force is measured in newtons (N)."},
  {department:"Science",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Mathematics",question:"What is 15% of 200?",options:["15","20","30","45"],answer:2,explanation:"15% of 200 = 0.15 × 200 = 30."},
  {department:"Science",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Physics",question:"Which energy does a moving object possess?",options:["Chemical energy","Kinetic energy","Sound energy","Nuclear energy"],answer:1,explanation:"Kinetic energy is the energy an object has because of its motion."},
  {department:"Science",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Biology",question:"Which gas do green plants take in during photosynthesis?",options:["Oxygen","Nitrogen","Carbon dioxide","Hydrogen"],answer:2,explanation:"Plants use carbon dioxide and water to make glucose during photosynthesis."},
  {department:"Science",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Mathematics",question:"Solve: 7 × 8.",options:["48","54","56","64"],answer:2,explanation:"7 multiplied by 8 equals 56."},
  {department:"Commercial",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Commerce",question:"What is the main purpose of trade?",options:["To exchange goods and services","To stop production","To destroy goods","To avoid consumers"],answer:0,explanation:"Trade involves buying, selling, or exchanging goods and services."},
  {department:"Commercial",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Accounting",question:"Which document usually records goods sold on credit?",options:["Invoice","Receipt only","Cheque book","Timetable"],answer:0,explanation:"An invoice lists goods or services supplied and the amount owed."},
  {department:"Commercial",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Economics",question:"What is the basic economic problem caused by limited resources?",options:["Surplus","Scarcity","Inflation only","Profit"],answer:1,explanation:"Scarcity means resources are limited while human wants are many."},
  {department:"Commercial",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Business Studies",question:"An entrepreneur is a person who mainly...",options:["Avoids all decisions","Organises a business and takes risks","Only buys personal items","Sets school exams"],answer:1,explanation:"Entrepreneurs organise resources, make business decisions, and take business risks."},
  {department:"Commercial",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Accounting",question:"If sales are ₦5,000 and expenses are ₦2,000, what is the amount left before other costs?",options:["₦2,000","₦3,000","₦5,000","₦7,000"],answer:1,explanation:"₦5,000 − ₦2,000 = ₦3,000."},
  {department:"Commercial",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Economics",question:"A person who buys goods or services for use is called a...",options:["Producer","Wholesaler","Consumer","Exporter"],answer:2,explanation:"A consumer uses goods and services to satisfy needs and wants."},
  {department:"Arts",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"English",question:"Choose the correctly spelled word.",options:["Neccessary","Necessary","Necesary","Neccesary"],answer:1,explanation:"The correct spelling is necessary."},
  {department:"Arts",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Literature",question:"Who is a character in a story or play?",options:["A person or figure in the work","The book cover","The publisher only","The chapter number"],answer:0,explanation:"Characters are the people, animals, or figures that take part in a literary work."},
  {department:"Arts",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Government",question:"What is a constitution?",options:["A country's fundamental set of rules","A market price list","A school uniform","A sports result"],answer:0,explanation:"A constitution sets out the basic principles and rules for governing a country."},
  {department:"Arts",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"History",question:"History is mainly the study of...",options:["Future predictions","Past events and human experiences","Chemical reactions","Only numbers"],answer:1,explanation:"History studies and interprets past events and human experiences."},
  {department:"Arts",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"English",question:"Which word is a noun in this sentence: 'The bright star shines'?",options:["bright","shines","the","star"],answer:3,explanation:"Star names a thing, so it is a noun."},
  {department:"Arts",classes:["JSS1","JSS2","JSS3","SS1","SS2","SS3"],subject:"Government",question:"In a democracy, political power ultimately belongs to...",options:["The people","One family forever","Only the police","Foreign visitors"],answer:0,explanation:"Democracy is based on the authority and participation of the people."}
];

let quizQuestions = [];
let questionIndex = 0;
let score = 0;
let answered = false;
let toastTimer;

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
}

function selectedDepartment() { return $("#departmentSelect").value; }
function selectedClass() { return $("#classSelect").value; }

function setDepartment(department) {
  $("#departmentSelect").value = department;
  $$(".department-card").forEach(card => card.classList.toggle("active", card.dataset.dept === department));
}

$$(".department-card").forEach(card => card.addEventListener("click", () => setDepartment(card.dataset.dept)));
$("#departmentSelect").addEventListener("change", () => setDepartment(selectedDepartment()));

function shuffle(array) {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function startQuiz() {
  const department = selectedDepartment();
  const className = selectedClass();
  const count = Number($("#questionCount").value);
  const matching = questionBank.filter(q => q.department === department && q.classes.includes(className));
  if (!matching.length) {
    showToast("There are no questions for this selection yet.");
    return;
  }
  quizQuestions = shuffle(matching).slice(0, Math.min(count, matching.length));
  questionIndex = 0;
  score = 0;
  $("#quizPanel").classList.remove("hidden");
  $("#quizTitle").textContent = `${department} personal quiz`;
  $("#quizCategory").textContent = `${department.toUpperCase()} • ${className}`;
  $("#quizPanel").scrollIntoView({behavior:"smooth", block:"start"});
  renderQuestion();
}

function renderQuestion() {
  answered = false;
  const q = quizQuestions[questionIndex];
  $("#questionNumber").textContent = `QUESTION ${String(questionIndex + 1).padStart(2, "0")}`;
  $("#questionText").textContent = q.question;
  $("#quizProgressText").textContent = `Question ${questionIndex + 1} of ${quizQuestions.length}`;
  $("#quizProgressBar").style.width = `${(questionIndex / quizQuestions.length) * 100}%`;
  $("#answerFeedback").textContent = "";
  $("#answerFeedback").className = "feedback";
  $("#nextQuestionBtn").disabled = true;
  $("#nextQuestionBtn").textContent = questionIndex === quizQuestions.length - 1 ? "See results →" : "Next question →";
  const answers = $("#answers");
  answers.replaceChildren();
  q.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = "answer-option";
    button.type = "button";
    button.textContent = `${String.fromCharCode(65 + index)}. ${option}`;
    button.addEventListener("click", () => chooseAnswer(index));
    answers.appendChild(button);
  });
}

function chooseAnswer(choice) {
  if (answered) return;
  answered = true;
  const q = quizQuestions[questionIndex];
  const buttons = $$(".answer-option");
  buttons.forEach((button, index) => {
    button.disabled = true;
    if (index === q.answer) button.classList.add("correct");
    if (index === choice && choice !== q.answer) button.classList.add("incorrect");
  });
  const feedback = $("#answerFeedback");
  if (choice === q.answer) {
    score++;
    feedback.textContent = `Correct! ${q.explanation}`;
    feedback.classList.add("good");
  } else {
    feedback.textContent = `Not quite. ${q.explanation}`;
    feedback.classList.add("bad");
  }
  $("#nextQuestionBtn").disabled = false;
}

function showResults() {
  $("#quizProgressBar").style.width = "100%";
  $("#quizProgressText").textContent = "Quiz complete";
  $("#questionNumber").textContent = "YOUR RESULT";
  $("#questionText").textContent = `${score} out of ${quizQuestions.length} correct`;
  $("#answers").replaceChildren();
  const percentage = Math.round((score / quizQuestions.length) * 100);
  const result = document.createElement("p");
  result.className = "feedback good";
  result.textContent = percentage >= 80 ? `Excellent work! You scored ${percentage}%. Keep challenging yourself.` : percentage >= 50 ? `Good effort! You scored ${percentage}%. Review the explanations and try again.` : `You scored ${percentage}%. Keep practising—you can improve with each round.`;
  $("#answers").appendChild(result);
  $("#answerFeedback").textContent = "Your score is shown for this session. This demo does not save results to an online account.";
  $("#answerFeedback").className = "feedback";
  $("#nextQuestionBtn").textContent = "Try again →";
  $("#nextQuestionBtn").disabled = false;
  $("#nextQuestionBtn").dataset.results = "true";
}

$("#startQuizBtn").addEventListener("click", startQuiz);
$("#nextQuestionBtn").addEventListener("click", () => {
  if ($("#nextQuestionBtn").dataset.results === "true") {
    delete $("#nextQuestionBtn").dataset.results;
    startQuiz();
    return;
  }
  if (questionIndex < quizQuestions.length - 1) {
    questionIndex++;
    renderQuestion();
  } else {
    showResults();
  }
});
$("#quitQuizBtn").addEventListener("click", () => {
  $("#quizPanel").classList.add("hidden");
  window.location.hash = "#practice";
});
$("#soloModeBtn").addEventListener("click", () => {
  $("#practice").scrollIntoView({behavior:"smooth"});
  showToast("Choose your class and department to start a solo quiz.");
});
$("#duelModeBtn").addEventListener("click", () => showToast("Duel Arena is planned. Real 1-vs-1 matches need accounts, a server, and live syncing."));
$("#squadModeBtn").addEventListener("click", () => showToast("Squad Battle is planned. 4-vs-4 play needs a backend and live room system."));
$("#loginBtn").addEventListener("click", () => showToast("Student profiles and login will be added when a secure backend is connected."));

const savedName = localStorage.getItem("eduarenaStudentName");
$("#studentName").value = savedName || "";
$("#studentName").addEventListener("change", () => {
  const name = $("#studentName").value.trim();
  if (name) localStorage.setItem("eduarenaStudentName", name);
  else localStorage.removeItem("eduarenaStudentName");
});
